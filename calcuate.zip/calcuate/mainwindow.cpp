#include "mainwindow.h"
#include "ui_mainwindow.h"

static  double a[100];

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("简易计算器");

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_btn1_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    temp = temp + "1";
    ui->showlineedit->setText(ui->showlineedit->text()+"1");

}

void MainWindow::on_btn2_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    temp = temp + "2";
    ui->showlineedit->setText(ui->showlineedit->text()+"2");

}

void MainWindow::on_butn3_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + "3";
    ui->showlineedit->setText(ui->showlineedit->text()+"3");

}

void MainWindow::on_btn4_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + "4";
    ui->showlineedit->setText(ui->showlineedit->text()+"4");

}

void MainWindow::on_btn5_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    temp = temp + "5";
    ui->showlineedit->setText(ui->showlineedit->text()+"5");


}

void MainWindow::on_btn6_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    temp = temp + "6";
    ui->showlineedit->setText(ui->showlineedit->text()+"6");

}

void MainWindow::on_butn7_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + "7";
    ui->showlineedit->setText(ui->showlineedit->text()+"7");

}

void MainWindow::on_btn8_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + "8";
    ui->showlineedit->setText(ui->showlineedit->text()+"8");

}

void MainWindow::on_btn9_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
      temp = temp + "9";
    ui->showlineedit->setText(ui->showlineedit->text()+"9");
}

void MainWindow::on_btn0_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + "0";
    ui->showlineedit->setText(ui->showlineedit->text()+"0");
}

void MainWindow::on_btn_point_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     temp = temp + ".";
    ui->showlineedit->setText(ui->showlineedit->text()+".");
}
//退格
void MainWindow::on_clearonebtn_clicked()
{
    //获取当前的显示栏的显示数据
    QString str = ui->showlineedit->text();
    str.chop(1);
    ui->showlineedit->clear();
    ui->showlineedit->setText(ui->showlineedit->text()+str);

    if(temp!= "" && (sz[i-1] == "+" || sz[i-1] == "-"||sz[i-1] == "*" || sz[i-1] == "/"||sz[i-1] == ""))
    {
        temp.chop(1);
    }
    else if(temp == "" && (sz[i-1] == "+" || sz[i-1] == "-"||sz[i-1] == "*" || sz[i-1] == "/"))
    {
         sz[i]= "";
         i= i-1;
         temp = sz[i];
         if(i == 1)
         {
             sz[i]= "";
         }
    }
 }


void MainWindow::on_clearallbtn_clicked()
{
     ui->showlineedit->clear();
     int a1;
     for(a1 = 0;a1 < 100;a1++ )
     {
         sz[a1] = "";
     }
     for(a1 = 0;a1 < 100;a1++ )
     {
         sz1[a1] = "";
     }
     for(a1 = 0;a1 < 100;a1++ )
     {
         sz2[a1] = "";
     }
     for(a1 = 0;a1 < 100;a1++ )
     {
         a[a1] = 0;
     }

     flags = 1;
     i = 1;
     j =1;
     k =1;
     t =1;
     judge =0;
     temp = "";
}

void MainWindow::on_addbtn_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
     if(temp!= "")
     {
         ui->showlineedit->setText(ui->showlineedit->text()+"+");
         sz[i] =temp;
         temp = "";
         i = i+1;
         sz[i]= "+";
         i = i+1;
     }
     else
     {
       ui->showlineedit->setText(ui->showlineedit->text()+"+");
       sz[i]= "+";
       i = i +1;
     }
}


void MainWindow::on_divbtn_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    if(temp!= "")
    {
        ui->showlineedit->setText(ui->showlineedit->text()+"/");
        sz[i] =temp;
        temp = "";
        i = i+1;
        sz[i]= "/";
        i = i+1;
    }
    else
    {
      ui->showlineedit->setText(ui->showlineedit->text()+"/");
      sz[i]= "/";
      i = i +1;
    }
}

void MainWindow::on_subbtn_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    if(temp!= "")
    {
        ui->showlineedit->setText(ui->showlineedit->text()+"-");
        sz[i] =temp;
        temp = "";
        i = i+1;
        sz[i]= "-";
        i = i+1;
    }
    else
    {
      ui->showlineedit->setText(ui->showlineedit->text()+"-");
      sz[i]= "-";
      i = i +1;
    }
}

void MainWindow::on_mulbtn_clicked()
{
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
    if(temp!= "")
    {
        ui->showlineedit->setText(ui->showlineedit->text()+"*");
        sz[i] =temp;
        temp = "";
        i = i+1;
        sz[i]= "*";
        i = i+1;
    }
    else
    {
      ui->showlineedit->setText(ui->showlineedit->text()+"*");
      sz[i]= "*";
      i = i +1;
    }
}

void MainWindow::on_equbtn_clicked()
{
    double temp1;
    if(flags == 1)
    {
        flags =0;
        ui->showlineedit->clear();
    }
   if(judge == 0)
   {
       if(temp!= "")
       {
           ui->showlineedit->clear();
           sz[i] =temp;
           temp = "";
           i = i+1;
           judge = 1;
           temp1 = MainWindow::line(i);
           ui->showlineedit->setText(ui->showlineedit->text()+QString::number(temp1));

       }
       else
       {
         ui->showlineedit->clear();
         judge = 1;

         temp1 = MainWindow::line(i);
         ui->showlineedit->setText(ui->showlineedit->text()+QString::number(temp1));

       }

   }
   int a;
   for(a = 0;a < 100;a++ )
   {
       sz[a] = "";
   }
   for(a = 0;a < 100;a++ )
   {
       sz1[a] = "";
   }
   for(a = 0;a < 100;a++ )
   {
       sz2[a] = "";
   }

   temp1 = 0;
    flags = 1;
    i = 1;
    j =1;
    k =1;
    t =1;
    judge =0;
    temp = "";

}
double  MainWindow::line (int flag)
{
    for(j = 1;j<flag;j++)
    {
        if(sz[j]!= "+"&&sz[j]!= "-"&&sz[j]!= "*"&&sz[j]!= "/")
        {
            sz1[k]=sz[j];
            k=k+1;
        }
        else if(sz[j]=="+")
        {

             while(sz2[t-1]=="/"||sz2[t-1]=="*")
             {
                                  sz1[k]=sz2[t-1];
                                  k++;
                                  t=t-1;
              }
              if(sz2[t-1]==sz2[99])
                {
                    sz2[t]="+";t++;
                }
                else if(sz2[t-1]=="+"||sz2[t-1]=="-")
                {
                     sz2[t]="+";t++;
                }
                else if(sz2[t-1]=="/"||sz2[t-1]=="*")
                {
                    sz1[k]=sz2[t-1];
                    sz2[t-1]="+";
                    k++;

                }
        }
        else if(sz[j]=="-")
        {
                 while(sz2[t-1]=="/"||sz2[t-1]=="*")
                 {
                     sz1[k]=sz2[t-1];
                     k++;
                     t=t-1;
                 }

                    if(sz2[t-1]==sz2[99])
                   {
                        sz2[t]="-";t++;
                    }

                    else if(sz2[t-1]=="+"||sz2[t-1]=="-")
                    {
                         sz2[t]="-";t++;
                    }
                    else if(sz2[t-1]=="/"||sz2[t-1]=="*")
                    {
                        sz1[k]=sz2[t-1];
                        sz2[t-1]="-";
                        k++;
                    }

         }
        else if(sz[j]=="*")
        {
            if(sz2[t-1]==sz2[99])
            {
            sz2[t] = "*";t++;
            }
            else if(sz2[t-1]=="+"||sz2[t-1]=="-")
            {
                sz2[t] = "*";t++;
            }
            else if (sz2[t-1]=="*"||sz2[t-1]=="/")
            {
                sz2[t] = "*";t++;
            }
        }
         else if(sz[j]=="/")
         {
             if(sz2[t-1]==sz2[99])// vitual
             {
             sz2[t] = "/";t++;
             }
             else if(sz2[t-1]=="+"||sz2[t-1]=="-")
             {
                 sz2[t] = "/";t++;
             }
             else if (sz2[t-1]=="*"||sz2[t-1]=="/")
             {
                 sz2[t] = "/";t++;
             }
         }

    }
    int time;

    for(time =t-1;time>=1;time-- )
    {
        sz1[k]=sz2[time];
        k++;
    }
    return   MainWindow::cclt(&(sz1[1]),k);
}
double MainWindow::cclt(QString *xunz, int flag)
{

        int i=1;
        int j = 1;
        for(i=0;i<flag-1;i++)
                {
                    if(*(xunz+i)!="+"&&*(xunz+i)!="-"&&*(xunz+i)!="*"&&*(xunz+i)!="/")
                        {
                            a[j]=(*(xunz+i)).toDouble();
                            j++;
                        }
                    else if(*(xunz+i)=="+")
                        {
                            a[j-2]=a[j-1]+a[j-2];
                            j--;
                        }
                    else if(*(xunz+i)=="-")
                        {
                            a[j-2]=a[j-2]-a[j-1];
                            j--;
                        }
                    else if(*(xunz+i)=="*")
                        {
                            a[j-2]=a[j-1]*a[j-2];
                            j--;
                        }
                    else if(*(xunz+i)=="/")
                        {
                            a[j-2]=a[j-2]/a[j-1];
                            j--;
                        }
                }

                return a[1];
}
