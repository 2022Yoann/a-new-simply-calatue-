    #ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btn1_clicked();

    void on_btn2_clicked();

    void on_butn3_clicked();

    void on_btn4_clicked();

    void on_btn5_clicked();

    void on_btn6_clicked();

    void on_butn7_clicked();

    void on_btn8_clicked();

    void on_btn9_clicked();

    void on_btn0_clicked();

    void on_btn_point_clicked();

    void on_clearonebtn_clicked();

    void on_clearallbtn_clicked();

    void on_addbtn_clicked();

    void on_divbtn_clicked();

    void on_subbtn_clicked();

    void on_mulbtn_clicked();

    void on_equbtn_clicked();

private:
    Ui::MainWindow *ui;
    QString sz[100];
    QString sz1[100];
    QString sz2[100];


    QString temp = "";


    int i = 1;
    int j =1;
    int k =1;
    int t =1;

    int judge = 0;
    int flags = 0;

    double line(int flag);
    double cclt( QString *xunz,int flag);


};
#endif // MAINWINDOW_H

